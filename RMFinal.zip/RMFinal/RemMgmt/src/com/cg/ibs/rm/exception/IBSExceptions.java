package com.cg.ibs.rm.exception;

public class IBSExceptions extends Exception{

	public IBSExceptions(String message)
	{
		super(message);
	}
}
